<?php {?>

<link rel="stylesheet" type="text/css" href="footer.css"> 


	<div class = "footer">
		
	<span > 2016 © Graphic Era University 
	</span>


	</div>




<?php }?>